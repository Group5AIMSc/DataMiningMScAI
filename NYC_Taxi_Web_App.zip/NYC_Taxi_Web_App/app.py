import os
from flask import Flask, render_template, jsonify
import db
import pandas as pd

app = Flask(__name__, static_url_path='/static')

# --- Page Routes ---
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/trips_hour")
def trips_hour():
    return render_template("trips_hour.html")

@app.route("/trips_day")
def trips_day():
    return render_template("trips_day.html")

@app.route("/avg_fare_hour")
def avg_fare_hour():
    return render_template("avg_fare_hour.html")

@app.route("/tip_distribution")
def tip_distribution():
    return render_template("tip_distribution.html")

@app.route("/trip_distance")
def trip_distance():
    return render_template("trip_distance.html")

@app.route("/map")
def map_page():
    return render_template("map.html")

# --- API Endpoints ---

# 1. Trips per Hour
@app.route("/api/trips_per_hour")
def api_trips_per_hour():
    q = "SELECT pickup_hour AS hour, COUNT(*) AS trips FROM taxi_new GROUP BY pickup_hour ORDER BY pickup_hour;"
    df = db.read_sql(q)
    df["hour"] = df["hour"].astype(int)
    return jsonify(df.to_dict(orient="records"))

# 2. Trips per Day
@app.route("/api/trips_per_day")
def api_trips_per_day():
    q = "SELECT pickup_day AS day, COUNT(*) AS trips FROM taxi_new GROUP BY pickup_day ORDER BY pickup_day;"
    df = db.read_sql(q)
    df["day"] = df["day"].astype(int)
    return jsonify(df.to_dict(orient="records"))

# 3. Average Fare per Hour
@app.route("/api/avg_fare_hour")
def api_avg_fare_hour():
    q = "SELECT pickup_hour AS hour, AVG(fare_amount) AS avg_fare FROM taxi_new GROUP BY pickup_hour ORDER BY pickup_hour;"
    df = db.read_sql(q)
    df["hour"] = df["hour"].astype(int)
    df["avg_fare"] = df["avg_fare"].astype(float)
    return jsonify(df.to_dict(orient="records"))

4# Trip Distance Histogram
@app.route("/api/trip_distance")
def api_trip_distance():
    q = "SELECT trip_distance FROM taxi_new WHERE trip_distance > 0 AND trip_distance < 50;"
    df = db.read_sql(q)
    # Ensure numeric
    df["trip_distance"] = df["trip_distance"].astype(float)
    return jsonify(df["trip_distance"].tolist())


5# payment type Distribution 
# Payment Type Pie Chart
@app.route("/api/payment_type")
def api_payment_type():
    q = "SELECT payment_type, COUNT(*) AS count FROM taxi_new GROUP BY payment_type;"
    df = db.read_sql(q)
    df["payment_type"] = df["payment_type"].astype(str)
    return jsonify(df.to_dict(orient="records"))


# 6. Map: pickups vs dropoffs
@app.route("/api/map_points")
def api_map_points():
    q = """
    SELECT t.pulocationid, l1.latitude AS plat, l1.longitude AS plng,
           t.dolocationid, l2.latitude AS dlat, l2.longitude AS dlng
    FROM taxi_new t
    JOIN locations l1 ON t.PULocationID=l1.location_id
    JOIN locations l2 ON t.DOLocationID=l2.location_id
    LIMIT 1000;
    """
    df = db.read_sql(q)
    points = []
    for _, r in df.iterrows():
        points.append({"lat": r["plat"], "lng": r["plng"], "type": "pickup"})
        points.append({"lat": r["dlat"], "lng": r["dlng"], "type": "dropoff"})
    return jsonify(points)

# --- Run App ---
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
