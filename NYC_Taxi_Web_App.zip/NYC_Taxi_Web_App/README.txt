Overview

This web application visualizes NYC taxi trip data using an interactive Flask-based dashboard.
It displays six analytical graphs that help understand patterns in taxi trips, payments, and fares.

Features (6 Graphs)
1. Trips per Hour

Shows how many trips occur during each hour of the day.
Useful for identifying peak hours and passenger demand trends.

2. Trips per Day

Displays the number of trips for each day of the month.
Helps analyze daily traffic patterns and high/low activity days.

3. Average Fare per Hour

Shows how average fare prices change across the day.
Helps understand pricing trends and peak-fare hours.

4. Trip Distance Histogram

A histogram showing the distribution of trip distances.
Reveals the most common trip lengths and outliers.

5. Payment Type Distribution (Pie Chart)

A pie chart showing the percentage of trips paid by:

Cash

Credit Card

No Charge

Dispute

Unknown

Helps compare customer payment preferences.

6. Pickup & Dropoff Heatmap (Map)

A Google Maps heatmap visualizing the density of:

Blue = Pickups

Red = Drop-offs

Shows hotspot zones for where taxis start and end trips.