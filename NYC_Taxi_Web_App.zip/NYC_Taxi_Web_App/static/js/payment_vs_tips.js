{% extends "layout.html" %}
{% block content %}
<h2>Payment Type vs Tip Distribution</h2>
<div id="chart" style="height:500px;"></div>
<label>Sample size:
  <select id="sampleSize">
    <option value="1000">1000</option>
    <option value="2000">2000</option>
    <option value="5000" selected>5000</option>
  </select>
  <button id="reload">Reload</button>
</label>
<script>
async function draw(n=5000){
  const resp = await fetch('/api/payment_vs_tips?n='+n);
  const data = await resp.json();

  const traces = [];
  data.payment_types.forEach(pt=>{
    traces.push({ y:data.samples[pt], type:'box', name:'Payment '+pt, boxpoints:'outliers' });
  });

  Plotly.newPlot('chart', traces, { yaxis:{title:'Tip Amount'}, margin:{t:50} }, {responsive:true});
}

document.getElementById('reload').addEventListener('click', ()=>draw(document.getElementById('sampleSize').value));
draw();
</script>
{% endblock %}
