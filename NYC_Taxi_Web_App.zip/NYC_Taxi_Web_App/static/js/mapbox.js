// static/js/mapbox.js
mapboxgl.accessToken = 'YOUR_MAPBOX_TOKEN_HERE'; // Replace with your token
const map = new mapboxgl.Map({
  container: 'map-plot',
  style: 'mapbox://styles/mapbox/light-v11',
  center: [-73.985, 40.758], // NYC center
  zoom: 10
});

fetch('/api/map_data')
  .then(res => res.json())
  .then(data => {
    data.forEach(d => {
      if(d.pickup_latitude && d.pickup_longitude) {
        new mapboxgl.Circle({
          center: [d.pickup_longitude, d.pickup_latitude],
          radius: 50,
          color: 'yellow',
          opacity: 0.6
        }).addTo(map);
      }
      if(d.dropoff_latitude && d.dropoff_longitude) {
        new mapboxgl.Circle({
          center: [d.dropoff_longitude, d.dropoff_latitude],
          radius: 50,
          color: 'black',
          opacity: 0.6
        }).addTo(map);
      }
    });
  })
  .catch(err => console.error('Error loading map data:', err));
