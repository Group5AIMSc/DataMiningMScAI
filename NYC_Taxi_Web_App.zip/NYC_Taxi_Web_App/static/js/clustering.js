fetch('/api/clustering')
  .then(r => r.json())
  .then(data => {
    const x = data.map(d => d.trip_distance);
    const y = data.map(d => d.fare_amount);
    const z = data.map(d => d.passenger_count);
    const cluster = data.map(d => d.cluster);

    const trace = {
      x: x,
      y: y,
      z: z,
      mode: 'markers',
      marker: {
        size: 5,
        color: cluster,
        colorscale: 'Viridis'
      },
      type: 'scatter3d'
    };

    const layout = {
      margin: { l:0, r:0, b:0, t:0 },
      scene: { xaxis:{title:'Distance'}, yaxis:{title:'Fare'}, zaxis:{title:'Passengers'} }
    };

    Plotly.newPlot('cluster-3d', [trace], layout, {responsive:true});
  });
