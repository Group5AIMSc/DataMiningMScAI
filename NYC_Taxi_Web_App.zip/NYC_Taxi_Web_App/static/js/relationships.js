// static/js/relationships.js
fetch('/api/relationships')
  .then(r=>r.json())
  .then(data=>{
    const cols = ['trip_distance','fare_amount','tip_amount','passenger_count'];
    const vals = {};
    cols.forEach(c => vals[c] = data.map(d => +d[c]));

    function corr(x,y){
      const n=x.length; const mx = x.reduce((a,b)=>a+b,0)/n; const my = y.reduce((a,b)=>a+b,0)/n;
      let num=0, sx=0, sy=0;
      for(let i=0;i<n;i++){ num += (x[i]-mx)*(y[i]-my); sx += (x[i]-mx)**2; sy += (y[i]-my)**2; }
      return num/Math.sqrt(sx*sy);
    }
    const matrix = [];
    for(let i=0;i<cols.length;i++){
      const row=[];
      for(let j=0;j<cols.length;j++){
        row.push(corr(vals[cols[i]], vals[cols[j]]));
      }
      matrix.push(row);
    }
    const fig = { data:[{ z:matrix, x:cols, y:cols, type:'heatmap', colorscale:'RdBu', zmin:-1, zmax:1}], layout:{title:'Correlation Heatmap'} };
    Plotly.newPlot('relationships-heatmap', fig.data, fig.layout, {responsive:true});
  })
  .catch(err => {
    document.getElementById('relationships-heatmap').innerHTML = '<p style="color:red;">Unable to load data</p>';
    console.error(err);
  });
