// static/js/association.js

fetch('/api/association')
  .then(r => r.json())
  .then(data => {

    // Backend returned error?
    if (!data || data.error || data.length === 0) {
      document.getElementById('force-graph').innerHTML =
        "<p style='color:red;'>No association rules found.</p>";
      return;
    }

    // Build nodes and links for D3
    const nodesMap = new Map();
    const links = [];

    data.forEach(row => {

      const a = row.antecedent ? row.antecedent.toString() : "";
      const c = row.consequent ? row.consequent.toString() : "";

      if (!nodesMap.has(a)) nodesMap.set(a, { id: a });
      if (!nodesMap.has(c)) nodesMap.set(c, { id: c });

      links.push({
        source: a,
        target: c,
        lift: row.lift || 1,
        conf: row.confidence || 0
      });

    });

    const nodes = Array.from(nodesMap.values());

    const width = 900, height = 600;
    const svg = d3.select('#force-graph')
                  .html("")        // clear old SVGs
                  .append('svg')
                  .attr('width', width)
                  .attr('height', height);

    const sim = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(140))
      .force('charge', d3.forceManyBody().strength(-350))
      .force('center', d3.forceCenter(width / 2, height / 2));

    const link = svg.append('g')
      .selectAll('line')
      .data(links)
      .enter()
      .append('line')
      .attr('stroke-width', d => Math.max(1, d.lift * 1.5))
      .attr('stroke', '#777');

    const node = svg.append('g')
      .selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('r', 12)
      .attr('fill', '#3498db')
      .call(
        d3.drag()
          .on('start', dragstarted)
          .on('drag', dragged)
          .on('end', dragended)
      );

    const label = svg.append('g')
      .selectAll('text')
      .data(nodes)
      .enter()
      .append('text')
      .text(d => d.id)
      .attr('font-size', 10)
      .attr('dx', 14)
      .attr('dy', 4);

    sim.on('tick', () => {
      link
        .attr('x1', d => d.source.x)
        .attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x)
        .attr('y2', d => d.target.y);

      node
        .attr('cx', d => d.x)
        .attr('cy', d => d.y);

      label
        .attr('x', d => d.x)
        .attr('y', d => d.y);
    });

    function dragstarted(event, d) {
      if (!event.active) sim.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }
    function dragged(event, d) {
      d.fx = event.x;
      d.fy = event.y;
    }
    function dragended(event, d) {
      if (!event.active) sim.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

  })
  .catch(err => {
    document.getElementById('force-graph').innerHTML =
      '<p style="color:red;">Unable to load rules</p>';
    console.error(err);
  });
