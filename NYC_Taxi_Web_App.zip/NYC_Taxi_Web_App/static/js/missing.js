// static/js/missing.js
fetch('/api/missing')
  .then(r=>r.json())
  .then(arr=>{
    const data = Array.isArray(arr) ? arr[0] : arr;
    const cols = Object.keys(data);
    const vals = cols.map(c => +data[c]);
    const fig = { data:[{ x: cols, y: vals, type: 'bar', marker:{color:'#f7c200'} }], layout:{title:'Missing Values per Column'} };
    Plotly.newPlot('missing-heatmap', fig.data, fig.layout, {responsive:true});
  })
  .catch(err => {
    document.getElementById('missing-heatmap').innerHTML = '<p style="color:red;">Unable to load data</p>';
    console.error(err);
  });
