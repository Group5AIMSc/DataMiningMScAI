// static/js/overview.js
fetch('/api/overview')
  .then(r=>r.json())
  .then(data=>{
    const trip = data.map(d => +d.trip_distance).filter(v=>!isNaN(v));
    const fare = data.map(d => +d.fare_amount).filter(v=>!isNaN(v));
    const tip = data.map(d => +d.tip_amount).filter(v=>!isNaN(v));

    const traces = [
      { x: trip, type: 'histogram', name: 'Trip Distance', opacity:0.6, marker:{color:'#f7c200'} },
      { x: fare, type: 'histogram', name: 'Fare Amount', opacity:0.6, marker:{color:'#111'} },
      { x: tip, type: 'histogram', name: 'Tip Amount', opacity:0.6, marker:{color:'#444'} }
    ];
    const layout = { title: 'Attribute Distributions', barmode:'overlay', xaxis:{title:'Value'}, yaxis:{title:'Count'} };
    Plotly.newPlot('overview-chart', traces, layout, {responsive:true});
  })
  .catch(err => {
    document.getElementById('overview-chart').innerHTML = '<p style="color:red;">Unable to load data</p>';
    console.error(err);
  });
