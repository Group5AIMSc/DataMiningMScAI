import os
import pandas as pd
import psycopg2

def get_conn():
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        database=os.getenv("DB_NAME", "MyDB"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASS", "123")
    )

def read_sql(query):
    conn = get_conn()
    df = pd.read_sql(query, conn)
    conn.close()
    return df
